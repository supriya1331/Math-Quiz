# MathGame
My 1st full project using C++. It was the graduation project for the C++ course in the college.

# Idea
The app is a game that generates **random math questions** that increase gradually in challenging level.
Solve its 16 questions if you dare :D

# Impressions
This project is very significant to me because it was >80% self learning and I made its details with passion :).
